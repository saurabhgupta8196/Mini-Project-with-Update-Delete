
import { Injectable } from '@angular/core';

// add these things for subscribing and observeables
import { HttpClient } from '@angular/common/Http';

import { Observable } from 'rxjs';
import { course } from './course'
@Injectable({
  providedIn: 'root'
})
export class UserService {

  public _url = 'http://localhost:4004/get';
  public _url1 = 'http://localhost:4004/getCourses';
  public _url2 = 'http://localhost:4004/add';
  public _url3 = 'http://localhost:4004/update';
  public _url4 = 'http://localhost:4004/delete/';

  constructor(private http: HttpClient) { }

  getCourses(): Observable<any> {
    return this.http.get<any>(this._url1);
  }

  getData(): Observable<course[]> {
    return this.http.get<course[]>(this._url);
  }
  
  postData(ename: string, eduration: number): Observable<any> {
    return this.http.post(this._url2, {
      courseName: ename,
      courseDuration: eduration
    });
  }

  putData(updatecname, updatedname, updatecnamex, updatednamex): Observable<any> {
    return this.http.put(this._url3, {
      "updatecname": updatecname,
      "updatedname": updatedname,
      "updatecnamex": updatecnamex,
      "updatednamex": updatednamex
    });
  }

  deleteData(dname: string): Observable<any> {
    return this.http.delete(this._url4 + dname);
  }
}
