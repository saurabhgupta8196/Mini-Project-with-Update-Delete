export interface course {
    courseName: string;
    courseDuration: number;
}