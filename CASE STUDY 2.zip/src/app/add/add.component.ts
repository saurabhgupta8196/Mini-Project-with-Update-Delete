import { Component, OnInit } from '@angular/core';
import {
  ReactiveFormsModule,
  FormsModule,
  FormGroup,
  FormControl,
  Validators,
  FormBuilder
} from '@angular/forms';
import { BrowserModule } from '@angular/platform-browser';
import { platformBrowserDynamic } from '@angular/platform-browser-dynamic'
import { UserService } from '../user.service'
import { course } from '../course'
@Component({
  selector: 'app-add',
  templateUrl: './add.component.html',
  styleUrls: ['./add.component.css']
})
export class AddComponent implements OnInit {
  public courseD;
  public course: course[] = [];
  coursename: string;
  courseduration: number;
  validCourse: string;
  validDuration: boolean = false;
  updatecname: string;
  updatedname: number;
  updatecnamex: string;
  updatednamex: number;

  constructor(private userService: UserService) { }

  ngOnInit() {
    this.getData();
    this.createFormControls();
    this.createForm();
  }

  getData() {
    this.userService.getData().subscribe(data => this.course = data);
    return false;
  }

  myform: FormGroup;
  cName: FormControl;
  cDuration: FormControl;

  createFormControls() {
    this.cName = new FormControl('', Validators.required);
    this.cDuration = new FormControl('', Validators.required);
  }

  createForm() {
    this.myform = new FormGroup({
      cName: this.cName,
      cDuration: this.cDuration,
    });
  }

  getDuration() {
    console.log(this.validCourse);
    var search: boolean = false;
    if (this.validCourse != null) {
      for (var i = 0; i < this.course.length; i++) {
        if (this.validCourse == this.course[i].courseName) {
          this.courseD = this.course[i].courseName + " is of " + this.course[i].courseDuration + " hrs";
          search = true;
        }
      }
      if (search == false) {
        this.courseD = "Course not found!!"
      }
      this.validCourse = null;
    }
    else {
      this.courseD = "Provide Course Name to get its duration!!"
    }
  }


  postData() {
    this.userService.postData(this.coursename, this.courseduration).subscribe((data) => this.getData());
    alert("Course added successfully");
  }

  put1Data(x: string, y: number) {
    console.log(x);
    this.updatecname = x;
    this.updatedname = y;
    this.updatecnamex = x;
    this.updatednamex = y;
  }

  putData() {
    this.userService.putData(this.updatecname, this.updatedname, this.updatecnamex, this.updatednamex).subscribe((data) => this.getData());
    console.log(this.updatecname);
  }

  deleteData(x: string) {
    this.userService.deleteData(x).subscribe((data) => this.getData());
  }

  onSubmit(data) {
    if (this.myform.valid) {
      console.log("Course Name :" + data.cName);
      console.log("Course Duration :" + data.cDuration);
    }
    else {
      alert("All fields are *mandatory");
    }
    this.myform.reset();
  }
}

