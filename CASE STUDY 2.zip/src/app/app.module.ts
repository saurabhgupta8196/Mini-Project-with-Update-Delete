import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { AppComponent } from './app.component';
import { AddComponent } from './add/add.component';
// import { SearchComponent } from './search/search.component';
import { AppRoutingModule } from './/app-routing.module';

import { RouterModule,Routes} from '@angular/router';
import { UserService } from './user.service';
import { HttpClientModule } from '@angular/common/http';
import { CoursesWithJSONComponent } from './courses-with-json/courses-with-json.component';

const appRoutes: Routes=[
  {path :'addCourses',component: AddComponent},
  {path :'courseWithJSON',component: CoursesWithJSONComponent}
];
@NgModule({
  declarations: [
    AppComponent,
    AddComponent,
    CoursesWithJSONComponent
  ],
  imports: [
     BrowserModule,
    FormsModule,
    ReactiveFormsModule,
    RouterModule.forRoot(appRoutes),
    HttpClientModule
  ],
  providers: [UserService],
  bootstrap: [AppComponent]
})
export class AppModule { }
